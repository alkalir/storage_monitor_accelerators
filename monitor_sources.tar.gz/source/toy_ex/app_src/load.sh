#!/bin/bash
source $1
vivado -mode batch -source filter.tcl
